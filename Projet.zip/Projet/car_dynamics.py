import numpy as np

def bicycle_dynamics_continuous(state, control, L=2.5):
    """Continuous-time bicycle model dynamics."""
    x, y, theta, v = state
    a, delta = control

    dxdt = v * np.cos(theta)
    dydt = v * np.sin(theta)
    dthetadt = v / L * np.tan(delta)
    dvdt = a

    return np.array([dxdt, dydt, dthetadt, dvdt])


def frenet_bicycle_dynamics(x, u, kappa, L=2.5):
    """Continuous-time bicycle model dynamics in Frenet frame."""
    s, d, v, delta_psi = x
    a, delta = u

    denom = max(1.0 - kappa * d, 1e-5)
    
    ds_dt = v * np.cos(delta_psi) / denom
    dd_dt = v * np.sin(delta_psi)
    dv_dt = a
    dpsi_dt = v / L * np.tan(delta) - kappa * v * np.cos(delta_psi) / denom

    return np.array([ds_dt, dd_dt, dv_dt, dpsi_dt])


def rk4_integration(state, control, dt, dynamics):
    """One RK4 integration step."""
    k1 = dynamics(state, control)
    k2 = dynamics(state + 0.5 * dt * k1, control)
    k3 = dynamics(state + 0.5 * dt * k2, control)
    k4 = dynamics(state + dt * k3, control)

    return state + (dt / 6.0) * (k1 + 2*k2 + 2*k3 + k4)


def bicycle_dynamics_discrete(state, control, dt, L=2.5):
    """Bicycle model dynamics discretized using RK4"""
    new_state = rk4_integration(state, control, dt, lambda s, u: bicycle_dynamics_continuous(s, u, L))
    return new_state


def frenet_dynamics_discrete(x, u, kappa_func, dt, L=2.5):
    """RK4-discretized frenet dynamics."""
    def dynamics(x_local, u_local):
        s = x_local[0]
        kappa = kappa_func(s)
        return frenet_bicycle_dynamics(x_local, u_local, kappa, L)

    return rk4_integration(x, u, dt, dynamics)