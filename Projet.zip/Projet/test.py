import math
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from racetrack import generate_track
from optimal_trajectory import generate_optimal_traj
from car import Car
from ZS_Controller import zero_sum_best_response_frenet
from frenet import compute_curvature

def resample_centerline(centerline, num_points=500):
    # Compute cumulative distance along the original centerline
    ds = np.hypot(np.diff(centerline[:, 0]), np.diff(centerline[:, 1]))
    s = np.insert(np.cumsum(ds), 0, 0.0)

    # Create new s values to interpolate onto
    s_uniform = np.linspace(0, s[-1], num_points)

    # Interpolate x and y
    interp_x = interp1d(s, centerline[:, 0], kind='linear')
    interp_y = interp1d(s, centerline[:, 1], kind='linear')

    centerline_dense = np.stack([interp_x(s_uniform), interp_y(s_uniform)], axis=1)
    return centerline_dense, s_uniform

# --- Generate Track ---
num_points = 1000
Length, Width = 500, 6
track = generate_track(Length, Width)
track.plot()
centerline_raw = np.column_stack((track.xm, track.ym))

# Remove duplicate (xm, ym) points
_, unique_indices = np.unique(centerline_raw, axis=0, return_index=True)
centerline_raw = centerline_raw[np.sort(unique_indices)]

# Resample the centerline
centerline, centerline_frenet = resample_centerline(centerline_raw, num_points)

# Compute headings
diffs = np.diff(centerline, axis=0)
headings = np.arctan2(diffs[:, 1], diffs[:, 0])
headings = np.append(headings, headings[-1])

# --- Initialize Cars ---
g = 9.81
car1 = Car([track.xm[0], track.ym[0]+2, headings[0], 5.0], v_max=65.0, a_max=12.0, a_lat_max=1.5*g)
car2 = Car([track.xm[0], track.ym[0]-2, headings[0], 5.0], v_max=75.0, a_max=10.0, a_lat_max=2*g)

# --- Generate Optimal Trajectories ---
d_opt1 = generate_optimal_traj(centerline_frenet, track.width, car1.a_lat_max)
d_opt2 = generate_optimal_traj(centerline_frenet, track.width, car2.a_lat_max)

# --- Compute curvature ---
kappa = compute_curvature(centerline)
kappa_interp = interp1d(centerline_frenet, kappa, kind='linear', bounds_error=False, fill_value="extrapolate")

print("centerline :", centerline)
print("headings :", headings)
print("centerline_frenet :", centerline_frenet)
print("dopt1 :", d_opt1)
print("dopt2 :", d_opt2)
print("curvature:", kappa)

# # --- Simulation ---
s_goal = centerline_frenet[-1]
N = 20
dt = 0.05
T = 35
for t in range(T):
    print(f"Step {t+1}/{T}")
    
    # Get current Frenet coordinates
    s1, _ = car1.get_frenet_coords(centerline, headings)
    s2, _ = car2.get_frenet_coords(centerline, headings)

    # Find the closest index in the centerline
    idx_closest_1 = np.argmin(np.abs(centerline_frenet - s1))
    idx_closest_2 = np.argmin(np.abs(centerline_frenet - s2))

    # Move one step forward (saturate to avoid overflow)
    idx_next_1 = min(idx_closest_1 + int(math.floor(num_points/10)), len(centerline_frenet) - 1)
    idx_next_2 = min(idx_closest_2 + int(math.floor(num_points/10)), len(centerline_frenet) - 1)

    # Next reference point in s
    s_next_1 = centerline_frenet[idx_next_1]
    s_next_2 = centerline_frenet[idx_next_2]

    # Compute centerline curvature at current car position
    kappa_ref_1 = kappa_interp(s1)
    kappa_ref_2 = kappa_interp(s2)
    
    u1, u2 = zero_sum_best_response_frenet(
        car1, car2,
        d_opt1, d_opt2, centerline_frenet, kappa_interp, kappa_ref_1, kappa_ref_2,
        centerline, headings, Width, s_goal, s_next_1, s_next_2,
        N=N, dt=dt
    )
    car1.set_control(*u1)
    car2.set_control(*u2)
    car1.update()
    car2.update()

# --- Plotting ---
h1 = np.array(car1.history)
h2 = np.array(car2.history)

plt.figure(figsize=(10, 8))
plt.plot(track.xm, track.ym, 'k--', label='Centerline')
plt.plot(track.xb1, track.yb1, 'g--', label='Inner Boundary')
plt.plot(track.xb2, track.yb2, 'r--', label='Outer Boundary')
plt.plot(h1[:, 0], h1[:, 1], 'b-', label='Car 1')
plt.plot(h2[:, 0], h2[:, 1], 'orange', label='Car 2')
plt.axis('equal')
plt.legend()
plt.title("Zero-Sum Racing Simulation")
plt.xlabel("X")
plt.ylabel("Y")
plt.grid(True)
plt.show()