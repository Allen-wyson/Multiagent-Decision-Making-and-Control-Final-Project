function cost = costFunction(a1, a2, car1_next_state, car2_next_state, trackLength)
    if detectCollision(a1,a2)
        cost = 10^6;
        return;
    else
        d1 = trackLength - car1_next_state.pos;
        d2 = trackLength - car2_next_state.pos;
        cost = d1 - d2;
        return;
    end
end
